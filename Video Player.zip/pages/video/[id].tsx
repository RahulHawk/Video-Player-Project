import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import { Box, Typography, Skeleton, CardMedia, List, ListItem, ListItemText, Grid } from "@mui/material";

interface Video {
  url: string;
  name: string;
  description: string;
  uploadDate: string;
}

export default function VideoDetails() {
  const router = useRouter();
  const { id } = router.query;
  const [videos, setVideos] = useState<Video[]>([]);
  const [video, setVideo] = useState<Video | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const storedVideos = JSON.parse(localStorage.getItem("videos") || "[]");
    setVideos(storedVideos);

    if (id !== undefined) {
      setIsLoading(true);
      setTimeout(() => {
        setVideo(storedVideos[Number(id)] || null);
        setIsLoading(false);
      }, 500);
    }
  }, [id]);

  if (isLoading) {
    return (
      <Box sx={{ width: "100vw", minHeight: "100vh", bgcolor: "#121212", color: "white", p: 2 }}>
        <Skeleton variant="rectangular" width="70%" height={400} />
        <Skeleton variant="text" width="50%" height={40} sx={{ mt: 2 }} />
        <Skeleton variant="text" width="30%" height={20} />
        <Skeleton variant="text" width="60%" height={60} sx={{ mt: 1 }} />
      </Box>
    );
  }

  if (!video) return <Typography variant="h6">Video not found</Typography>;

  return (
    <Box sx={{ width: "100vw", minHeight: "100vh", bgcolor: "#121212", color: "white", p: 2 }}>
      <Grid container spacing={3}>
        <Grid item xs={12} md={8}>
          <Box>
            <video
              controls
              autoPlay
              style={{
                width: "100%",
                borderRadius: "10px",
                boxShadow: "0px 4px 10px rgba(255, 255, 255, 0.1)",
              }}
            >
              <source src={video.url} type="video/mp4" />
              Your browser does not support the video tag.
            </video>

            <Typography variant="h4" sx={{ fontWeight: "bold", mt: 2 }}>
              {video.name}
            </Typography>

            <Typography variant="body2" sx={{ color: "gray", mt: 1 }}>
              Uploaded on: {video.uploadDate || "Unknown"}
            </Typography>

            <Typography variant="body1" sx={{ mt: 1, bgcolor: "#1E1E1E", p: 2, borderRadius: "5px" }}>
              {video.description || "No description available."}
            </Typography>
          </Box>
        </Grid>

        <Grid item xs={12} md={4}>
          <Typography variant="h6" sx={{ fontWeight: "bold", mb: 2 }}>
            More Videos
          </Typography>
          <List>
            {videos.map((vid, index) => (
              <ListItem
                key={index}
                sx={{
                  cursor: "pointer",
                  bgcolor: index === Number(id) ? "#333" : "transparent",
                  borderRadius: "5px",
                  mb: 1,
                  "&:hover": { bgcolor: "#444" },
                }}
                onClick={() => router.push(`/video/${index}`)}
              >
                <CardMedia component="video" src={vid.url} sx={{ width: 100, height: 60, borderRadius: "5px" }} />
                <ListItemText
                  primary={vid.name}
                  secondary={vid.uploadDate || "Unknown"}
                  sx={{ ml: 2, color: "white" }}
                />
              </ListItem>
            ))}
          </List>
        </Grid>
      </Grid>
    </Box>
  );
}
