import { useState } from "react";
import { useRouter } from "next/router";
import { useDropzone } from "react-dropzone";
import { Button, Box, Typography, TextField, Paper } from "@mui/material";

export default function UploadPage() {
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [videoURL, setVideoURL] = useState<string | null>(null);
  const [videoName, setVideoName] = useState("");
  const [videoDescription, setVideoDescription] = useState("");
  const router = useRouter();

  const onDrop = (acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (file) {
      setVideoFile(file);
      setVideoURL(URL.createObjectURL(file)); 
      setVideoName(file.name.replace(/\.[^/.]+$/, ""));
    }
  };

  const { getRootProps, getInputProps } = useDropzone({
    accept: { "video/*": [] },
    onDrop,
    multiple: false,
  });

  const handleSave = () => {
    if (!videoFile || !videoName.trim()) return;

    const storedVideos = JSON.parse(localStorage.getItem("videos") || "[]");
    const newVideo = {
      url: videoURL,
      name: videoName.trim(),
      description: videoDescription.trim(),
    };

    localStorage.setItem("videos", JSON.stringify([...storedVideos, newVideo]));
    router.push("/");
  };

  return (
    <Box
      sx={{
        width: "100vw",
        height: "100vh",
        bgcolor: "#121212",
        color: "white",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        padding: "20px",
      }}
    >
      <Typography variant="h4" gutterBottom sx={{ fontWeight: "bold" }}>
        Upload Your Video
      </Typography>

      <Paper
        sx={{
          width: "100%",
          maxWidth: "800px",
          padding: "30px",
          bgcolor: "#1E1E1E",
          borderRadius: "10px",
          boxShadow: "0px 4px 10px rgba(255, 255, 255, 0.1)",
          textAlign: "center",
        }}
      >
        <Box
          {...getRootProps()}
          sx={{
            border: "2px dashed gray",
            padding: "30px",
            borderRadius: "10px",
            cursor: "pointer",
            "&:hover": { borderColor: "white" },
          }}
        >
          <input {...getInputProps()} />
          <Typography>Drag & Drop your video here or click to select</Typography>
        </Box>

        {videoURL && (
          <Box sx={{ mt: 3 }}>
            <Typography variant="h6">Video Preview:</Typography>
            <video
              src={videoURL}
              controls
              style={{
                width: "100%",
                maxHeight: "400px",
                borderRadius: "10px",
                boxShadow: "0px 4px 10px rgba(255, 255, 255, 0.2)",
              }}
            />

            <TextField
              label="Rename Video"
              variant="outlined"
              fullWidth
              value={videoName}
              onChange={(e) => setVideoName(e.target.value)}
              sx={{
                mt: 2,
                input: { color: "white" },
                "& label": { color: "gray" },
                "& .MuiOutlinedInput-root": {
                  "& fieldset": { borderColor: "gray" },
                  "&:hover fieldset": { borderColor: "white" },
                  "&.Mui-focused fieldset": { borderColor: "#4CAF50" },
                },
              }}
            />

            <TextField
              label="Video Description"
              variant="outlined"
              multiline
              rows={3}
              fullWidth
              sx={{
                mt: 2,
                input: { color: "white" },
                "& label": { color: "gray" },
                "& .MuiOutlinedInput-root": {
                  "& fieldset": { borderColor: "gray" },
                  "&:hover fieldset": { borderColor: "white" },
                  "&.Mui-focused fieldset": { borderColor: "#4CAF50" },
                },
              }}
              value={videoDescription}
              onChange={(e) => setVideoDescription(e.target.value)}
            />

            <Button
              variant="contained"
              sx={{
                mt: 2,
                bgcolor: "#4CAF50",
                "&:hover": { bgcolor: "#388E3C" },
              }}
              onClick={handleSave}
            >
              Save Video
            </Button>
          </Box>
        )}
      </Paper>

      <Button
        variant="outlined"
        sx={{
          mt: 3,
          color: "white",
          borderColor: "white",
          "&:hover": { bgcolor: "white", color: "#121212" },
        }}
        onClick={() => router.push("/")}
      >
        Go to Video Library
      </Button>
    </Box>
  );
}
