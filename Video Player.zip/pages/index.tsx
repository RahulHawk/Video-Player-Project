import { useState, useEffect } from "react";
import { Button, Grid, Card, CardMedia, CardContent, Typography, Box, IconButton, Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle } from "@mui/material";
import ViewModuleIcon from "@mui/icons-material/ViewModule";
import ViewListIcon from "@mui/icons-material/ViewList";
import DeleteIcon from "@mui/icons-material/Delete";
import { useRouter } from "next/router";

interface Video {
  url: string;
  name: string;
  description: string;
  uploadDate: string;
}

export default function VideoLibrary() {
  const [videos, setVideos] = useState<Video[]>([]);
  const [isGridView, setIsGridView] = useState(true);
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);
  const [deleteIndex, setDeleteIndex] = useState<number | null>(null); // Track index for deletion
  const router = useRouter();

  useEffect(() => {
    const storedVideos = JSON.parse(localStorage.getItem("videos") || "[]").map((video: Video) => ({
      ...video,
      uploadDate: video.uploadDate || new Date().toISOString(),
    }));
    setVideos(storedVideos);
    localStorage.setItem("videos", JSON.stringify(storedVideos));
  }, []);

  const handleDelete = () => {
    if (deleteIndex !== null) {
      const updatedVideos = videos.filter((_, i) => i !== deleteIndex);
      setVideos(updatedVideos);
      localStorage.setItem("videos", JSON.stringify(updatedVideos));
      setDeleteIndex(null);
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric" });
  };

  const truncateDescription = (description: string) => {
    return description.length > 50 ? description.slice(0, 50) + "..." : description;
  };

  return (
    <Box
      sx={{
        width: "100vw",
        minHeight: "100vh",
        bgcolor: "#121212",
        color: "white",
        padding: "20px",
        overflowY: "auto",
      }}
    >
      <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 2 }}>
        <Typography variant="h4" sx={{ fontWeight: "bold" }}>
          Video Library
        </Typography>

        <Box>
          <Button
            variant="contained"
            sx={{ bgcolor: "#4CAF50", "&:hover": { bgcolor: "#388E3C" }, mr: 2 }}
            onClick={() => router.push("/upload")}
          >
            Upload Videos
          </Button>

          <Button
            variant="contained"
            onClick={() => setIsGridView(!isGridView)}
            sx={{ bgcolor: "#333", "&:hover": { bgcolor: "#555" } }}
          >
            {isGridView ? <ViewListIcon /> : <ViewModuleIcon />} Toggle View
          </Button>
        </Box>
      </Box>

      <Grid container spacing={2} justifyContent="center">
        {videos.length > 0 ? (
          videos.map((video, index) => (
            <Grid item key={index} xs={isGridView ? 6 : 12} sm={isGridView ? 4 : 12} md={isGridView ? 3 : 12}>
              <Card
                sx={{
                  position: "relative",
                  display: "flex",
                  alignItems: "center",
                  flexDirection: isGridView ? "column" : "row",
                  padding: "10px",
                  gap: "10px",
                  bgcolor: "transparent",
                  boxShadow: "none",
                  transition: "all 0.3s ease",
                  cursor: "pointer",
                  "&:hover": {
                    transform: "scale(1.03)",
                    boxShadow: "0 4px 10px rgba(255, 255, 255, 0.2)",
                  },
                }}
                onClick={() => window.open(`/video/${index}`, "_blank")}
                onMouseEnter={() => setHoveredIndex(index)}
                onMouseLeave={() => setHoveredIndex(null)}
              >
                <CardMedia
                  component="video"
                  src={video.url}
                  controls={false}
                  sx={{
                    width: isGridView ? "100%" : "200px",
                    height: isGridView ? "auto" : "120px",
                    borderRadius: "8px",
                  }}
                />
                <CardContent sx={{ flex: 1, textAlign: "left" }}>
                  <Typography variant="body1" sx={{ color: "white", fontWeight: "bold" }}>
                    {video.name}
                  </Typography>

                  {!isGridView && (
                    <Typography
                      variant="body2"
                      sx={{ color: "#bbb", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}
                    >
                      {truncateDescription(video.description || "No description available")}
                    </Typography>
                  )}

                  <Typography
                    variant="caption"
                    sx={{ display: "block", color: "#888", mt: 1, fontSize: "0.8rem" }}
                  >
                    Uploaded on {formatDate(video.uploadDate)}
                  </Typography>
                </CardContent>

                {hoveredIndex === index && (
                  <IconButton
                    sx={{
                      position: "absolute",
                      top: 50,
                      right: 50,
                      bgcolor: "rgba(0,0,0,0.6)",
                      color: "white",
                      "&:hover": { bgcolor: "red" },
                    }}
                    onClick={(e) => {
                      e.stopPropagation(); 
                      setDeleteIndex(index); 
                    }}
                  >
                    <DeleteIcon />
                  </IconButton>
                )}
              </Card>
            </Grid>
          ))
        ) : (
          <Typography sx={{ textAlign: "center", width: "100%" }}>No videos available</Typography>
        )}
      </Grid>

      <Dialog open={deleteIndex !== null} onClose={() => setDeleteIndex(null)}>
        <DialogTitle>Delete Video</DialogTitle>
        <DialogContent>
          <DialogContentText>Are you sure you want to delete this video?</DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteIndex(null)} color="primary">
            Cancel
          </Button>
          <Button onClick={handleDelete} color="error" variant="contained">
            Delete
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
