import { useCallback } from "react";
import { useDropzone } from "react-dropzone";
import { Box, Typography } from "@mui/material";

const VideoUploader = ({ onUpload }: { onUpload: (file: File) => void }) => {
  const onDrop = useCallback((acceptedFiles: File[]) => {
    acceptedFiles.forEach((file) => {
      if (file.type.startsWith("video/")) {
        onUpload(file);
      }
    });
  }, [onUpload]);

  const { getRootProps, getInputProps } = useDropzone({ 
    onDrop, 
    accept: { "video/*": [] } 
  });

  return (
    <Box 
      {...getRootProps()} 
      sx={{ 
        border: "2px dashed gray", 
        padding: "30px", 
        textAlign: "center", 
        cursor: "pointer",
        borderRadius: "10px",
        transition: "0.3s",
        "&:hover": {
          borderColor: "#4CAF50",
          backgroundColor: "rgba(76, 175, 80, 0.1)"
        }
      }}
    >
      <input {...getInputProps()} />
      <Typography variant="body1" sx={{ color: "gray" }}>
        Drag & drop your video here, or click to select a file
      </Typography>
    </Box>
  );
};

export default VideoUploader;
