import React from "react";
import ReactPlayer from "react-player";

const VideoPlayer = ({ src }: { src: string }) => {
  return (
    <ReactPlayer url={src} controls width="100%" height="auto" />
  );
};

export default VideoPlayer;
